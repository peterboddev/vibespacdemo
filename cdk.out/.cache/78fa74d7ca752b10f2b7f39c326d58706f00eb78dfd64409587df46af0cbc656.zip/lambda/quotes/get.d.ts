export declare const handler: import("..").LambdaHandler;
//# sourceMappingURL=get.d.ts.map