import { LambdaHandler } from './types';
export declare const withErrorHandler: (handler: LambdaHandler) => LambdaHandler;
export declare const withCors: (handler: LambdaHandler) => LambdaHandler;
export declare const withValidation: (_schema: any, handler: LambdaHandler) => LambdaHandler;
//# sourceMappingURL=middleware.d.ts.map