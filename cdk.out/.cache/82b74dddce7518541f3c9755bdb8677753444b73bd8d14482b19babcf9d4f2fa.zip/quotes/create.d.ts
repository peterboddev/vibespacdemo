export declare const handler: import("../shared/types").LambdaHandler;
//# sourceMappingURL=create.d.ts.map