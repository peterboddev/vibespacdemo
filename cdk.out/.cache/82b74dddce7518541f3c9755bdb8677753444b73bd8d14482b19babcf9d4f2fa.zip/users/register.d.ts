export declare const handler: import("..").LambdaHandler;
//# sourceMappingURL=register.d.ts.map