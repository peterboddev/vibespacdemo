export declare const handler: import("..").LambdaHandler;
//# sourceMappingURL=login.d.ts.map