export declare const handler: import("..").LambdaHandler;
//# sourceMappingURL=handler.d.ts.map